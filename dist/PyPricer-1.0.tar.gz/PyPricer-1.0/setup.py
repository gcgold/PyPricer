from setuptools import setup

setup(
    name='PyPricer',
    version='1.0',
    package_dir = {'': 'PyPricer'},
    py_modules=['PyPricer'],
    url='',
    license='GNU Lesser General Public License v3.0',
    author='Golden',
    author_email='',
    description=''
)
