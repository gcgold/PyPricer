# PyPricer
API Access to the EISPricing

This code is based on the initial work performed by vfgolden and the EIS Pricing Project.  This effort just makes the
publicly available pricing data accessible by API.